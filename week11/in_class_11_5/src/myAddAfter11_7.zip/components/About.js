import React from 'react';

function About(props) {
    return (
        <div>
            <h2> All about us!!!! </h2>
        </div>
    );
}

export default About;