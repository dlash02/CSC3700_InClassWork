import React from 'react';

function NotFound(props) {
    return (
        <div>
            You page has not been found
        </div>
    );
}

export default NotFound;