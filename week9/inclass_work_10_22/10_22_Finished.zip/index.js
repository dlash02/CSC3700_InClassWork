console.log('Thank you for using WebStorm 💙')
